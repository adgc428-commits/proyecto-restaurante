const contactButton = document.getElementById("contactButton");
const message = document.getElementById("message");

contactButton.addEventListener("click", () => {
  message.textContent = "¡Gracias por tu interés! Contáctanos directamente en el restaurante.";
});
